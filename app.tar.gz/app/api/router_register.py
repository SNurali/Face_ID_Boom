# app/api/router_register.py
from fastapi import APIRouter, HTTPException, Depends, Body, Request
from pydantic import BaseModel, Field, ValidationError as PydanticValidationError
from typing import Optional
import traceback
import json
from datetime import datetime

from app.schemas.register import RegisterInput
from app.utils.validation import validate_all_register_fields, ValidationError
from app.services.provider_ingest_service import ProviderIngestService
from app.dependencies import get_face_app
from app.repositories.faceid_repo import FaceIdRepo

router = APIRouter()

def get_ingest_service(face_app=Depends(get_face_app)):
    repo = FaceIdRepo()
    return ProviderIngestService(repo, face_app)

class WebRegisterInput(BaseModel):
    photos_base64: Optional[str] = Field(None, description="Base64 фото из фронта")
    full_name: Optional[str] = Field(None, description="ФИО")
    passport: Optional[str] = Field(None, description="Номер паспорта")
    gender: Optional[str] = Field(None, description="Пол: '1' или '2' как строка")
    citizenship: Optional[str] = None
    birth_date: Optional[str] = None
    visa_type: Optional[str] = None
    visa_number: Optional[str] = None
    entry_date: Optional[str] = None
    exit_date: Optional[str] = None

    model_config = {"extra": "ignore"}

@router.post("")
async def register_person(
    request: Request,
    raw_body: dict = Body(...),
    service: ProviderIngestService = Depends(get_ingest_service)
):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    log_prefix = f"[{timestamp}] REGISTER "

    print(f"\n{log_prefix}╔════════════════════════════════════════════════════════════╗")
    print(f"{log_prefix}║                  НОВЫЙ ЗАПРОС НА РЕГИСТРАЦИЮ                 ║")
    print(f"{log_prefix}╚════════════════════════════════════════════════════════════╝")

    # 1. Заголовки
    print(f"{log_prefix}Raw request headers:")
    print(f"{log_prefix}  Content-Type: {request.headers.get('content-type')}")
    print(f"{log_prefix}  Content-Length: {request.headers.get('content-length')}")

    # 2. Сырой JSON
    print(f"{log_prefix}Полученный JSON (сырой dict):")
    try:
        print(json.dumps(raw_body, indent=2, ensure_ascii=False))
    except Exception as e:
        print(f"{log_prefix}Ошибка при печати raw_body: {str(e)}")
        print(f"{log_prefix}raw_body type: {type(raw_body)}")
        print(f"{log_prefix}raw_body keys: {list(raw_body.keys()) if isinstance(raw_body, dict) else 'не dict'}")

    # 3. Ожидаемая структура модели
    print(f"{log_prefix}Ожидаемая схема WebRegisterInput:")
    print(json.dumps(WebRegisterInput.model_json_schema(), indent=2, ensure_ascii=False))

    # 4. Парсинг в промежуточную модель
    print(f"{log_prefix}Попытка парсинга в WebRegisterInput...")
    try:
        input_data = WebRegisterInput(**raw_body)
        print(f"{log_prefix}✅ Успешно распарсилось! Полученные поля:")
        print(json.dumps(input_data.model_dump(), indent=2, ensure_ascii=False))
    except PydanticValidationError as ve:
        print(f"{log_prefix}❌ Pydantic ValidationError:")
        print(json.dumps(ve.errors(), indent=2, ensure_ascii=False))
        raise HTTPException(422, detail={"errors": ve.errors()})
    except Exception as e:
        print(f"{log_prefix}❌ Неожиданная ошибка парсинга: {str(e)}")
        traceback.print_exc()
        raise HTTPException(422, detail=f"Парсинг JSON: {str(e)}")

    # 5. Преобразование → RegisterInput
    print(f"{log_prefix}🔄 Преобразование в RegisterInput...")
    try:
        # Обязательные поля
        if not input_data.photos_base64:
            raise ValueError("photos_base64 обязательно — загрузите фото")
        if not input_data.full_name or not input_data.full_name.strip():
            raise ValueError("full_name не может быть пустым — заполните ФИО")
        if not input_data.passport or not input_data.passport.strip():
            raise ValueError("passport обязательно — заполните номер паспорта")

        # Преобразование gender → sex (int)
        gender_value = input_data.gender
        if gender_value is None:
            sex = None
        else:
            try:
                sex = int(gender_value)
                if sex not in (1, 2):
                    raise ValueError("Пол должен быть 1 (мужской) или 2 (женский)")
            except ValueError:
                raise ValueError("Некорректное значение пола. Используйте '1' или '2'")

        register_data = RegisterInput(
            photos_base64=input_data.photos_base64,
            full_name=input_data.full_name.strip(),
            passport=input_data.passport.strip(),
            sex=sex,                             # ← ключевое исправление
            citizenship=input_data.citizenship.strip() if input_data.citizenship else None,
            birth_date=input_data.birth_date.strip() if input_data.birth_date else None,
            visa_type=input_data.visa_type.strip() if input_data.visa_type else None,
            visa_number=input_data.visa_number.strip() if input_data.visa_number else None,
            entry_date=input_data.entry_date.strip() if input_data.entry_date else None,
            exit_date=input_data.exit_date.strip() if input_data.exit_date else None,
        )

        print(f"{log_prefix}✅ Успешно создана RegisterInput:")
        print(json.dumps(register_data.model_dump(), indent=2, ensure_ascii=False))

    except ValueError as ve:
        print(f"{log_prefix}❌ ValueError при проверке/преобразовании: {str(ve)}")
        raise HTTPException(400, detail=str(ve))
    except Exception as e:
        print(f"{log_prefix}❌ Ошибка при создании RegisterInput: {str(e)}")
        traceback.print_exc()
        raise HTTPException(422, detail=f"Преобразование данных: {str(e)}")

    # 6. Кастомная валидация
    print(f"{log_prefix}🔍 Запуск validate_all_register_fields...")
    try:
        validate_all_register_fields(register_data)
        print(f"{log_prefix}✅ Валидация прошла успешно")
    except ValidationError as ve:
        print(f"{log_prefix}❌ Кастомная ValidationError: {ve.field or 'общее'} → {ve.message}")
        raise HTTPException(400, detail=f"{ve.field or 'general'}: {ve.message}")

    # 7. Сохранение
    print(f"{log_prefix}🚀 Запуск service.ingest()...")
    try:
        person_id = await service.ingest(register_data)
        print(f"{log_prefix}🎉 УСПЕХ! person_id = {person_id}")
        print(f"{log_prefix}╚════════════════════════════════════════════════════════════╝\n")
        return {
            "status": "ok",
            "message": "Зарегистрировано успешно",
            "person_id": person_id,
            "data": register_data.model_dump()  # полезно для дебага
        }
    except Exception as e:
        print(f"{log_prefix}💥 ОШИБКА ingest(): {str(e)}")
        traceback.print_exc()
        print(f"{log_prefix}╚════════════════════════════════════════════════════════════╝\n")
        raise HTTPException(500, detail=f"Сохранение в БД: {str(e)}")