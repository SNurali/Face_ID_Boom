# app/api/router_search.py
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
import base64
import numpy as np
import cv2

from app.services.search_service import SearchService
from app.dependencies import get_face_app
from app.repositories.faceid_repo import FaceIdRepo  # если нужен для получения метаданных

router = APIRouter()

class SearchRequest(BaseModel):
    image: str  # base64 строка

@router.post("/", summary="Поиск по фото (основной эндпоинт)")
async def search_face(
    request: SearchRequest,
    face_app=Depends(get_face_app)
):
    try:
        # Декодируем base64 → изображение
        header, encoded = request.image.split(",", 1)
        img_data = base64.b64decode(encoded)
        nparr = np.frombuffer(img_data, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

        if img is None:
            raise HTTPException(400, detail="Не удалось декодировать изображение")

        # Создаём сервис поиска
        search_service = SearchService(face_app=face_app)  # или через Depends, если реализовано

        # Выполняем поиск (адаптируй под реальную сигнатуру твоего SearchService)
        result = await search_service.search_by_image(
            img,
            top_k=5,
            threshold=0.6  # cosine similarity threshold
        )

        # Предполагаем, что search_by_image возвращает что-то вроде:
        # {
        #     "matches": [{"person_id": ..., "distance": ..., "payload": {...}}, ...],
        #     "query_faces_found": 1
        # }

        formatted_matches = []
        for match in result.get("matches", []):
            payload = match.get("payload", {})
            formatted_matches.append({
                "person_id": match["person_id"],
                "full_name": payload.get("full_name", "Не указано"),
                "passport": payload.get("passport_number", "-"),
                "gender": payload.get("gender", "-"),
                "citizenship": payload.get("citizenship", "-"),
                "birth_date": payload.get("birth_date", "-"),
                "distance": match["distance"],
                "confidence": round((1 - match["distance"]) * 100, 1),  # если distance = cosine distance
                "face_url": f"/static/images/persons/{match['person_id']}.jpg"  # если сохраняешь кропы
            })

        if formatted_matches:
            best = min(formatted_matches, key=lambda x: x["distance"])
            best_match = {
                "person_id": best["person_id"],
                "full_name": best["full_name"],
                "confidence": best["confidence"],
                "color": "green" if best["confidence"] >= 80 else "orange" if best["confidence"] >= 60 else "red"
            }
        else:
            best_match = {"confidence": 0, "color": "gray"}

        return {
            "status": "success",
            "matches": formatted_matches,
            "best_match": best_match,
            "query_faces_found": result.get("query_faces_found", 1),
            "message": "Поиск выполнен"
        }

    except Exception as e:
        raise HTTPException(500, detail=f"Ошибка поиска: {str(e)}")


# Оставляем тестовый эндпоинт, если хочешь (можно удалить позже)
# @router.post("/test-search", summary="Тестовый поиск по фото (для демо)")
# async def test_search(file: UploadFile = File(...)):
#     # ... можно оставить как было, или удалить
#     pass