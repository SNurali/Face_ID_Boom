# app/schemas/register.py
from pydantic import BaseModel
from typing import List, Optional

class RegisterInput(BaseModel):
    photos_base64: Optional[str] = None
    full_name: Optional[str] = None
    passport: Optional[str] = None
    gender: Optional[str] = None
    citizenship: Optional[str] = None
    birth_date: Optional[str] = None
    visa_type: Optional[str] = None
    visa_number: Optional[str] = None
    entry_date: Optional[str] = None
    exit_date: Optional[str] = None
    # ... другие поля, если есть