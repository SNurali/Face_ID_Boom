# app/services/search_service.py

from typing import Dict, Any, Optional

class SearchService:
    def __init__(self, repo, face_app):
        self.repo = repo
        self.face_app = face_app

    async def search_by_image_b64(self, image_b64: str, top_k: int = 5, **kwargs) -> Dict[str, Any]:
        # Заглушка — пока просто возвращаем пустой результат
        print("Поиск по фото запущен (заглушка)")
        return {
            "status": "ok",
            "message": "Поиск выполнен (заглушка)",
            "matches": []  # позже здесь будут реальные матчи
        }