// script.js
let video = document.getElementById('video');
let registerBtn = document.getElementById('registerBtn');
let checkDbBtn = document.getElementById('checkDbBtn');
let clearBtn = document.getElementById('clearBtn');
let statusText = document.getElementById('statusText');
let loadingSpinner = document.getElementById('loadingSpinner');
let overlay = document.getElementById('overlay');
let searchResult = document.getElementById('searchResult');
let searchMatches = document.getElementById('searchMatches');
let alertContainer = document.getElementById('alertContainer');

let stream = null;
let isProcessing = false;

// Модальное окно регистрации
const registerModal = new bootstrap.Modal(document.getElementById('registerModal'));

// Уведомление
function showAlert(message, type = 'success') {
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} alert-dismissible fade show d-flex align-items-center`;
    alert.innerHTML = `
        <i class="bi bi-${type === 'success' ? 'check-circle' : 'exclamation-triangle'} me-2"></i>
        ${message}
        <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert"></button>
    `;
    alertContainer.appendChild(alert);
    setTimeout(() => alert?.remove(), 7000);
}

// Статус + лоадер
function setStatus(text, loading = false) {
    statusText.textContent = text;
    loadingSpinner.style.display = loading ? 'inline-block' : 'none';
}

// Запуск камеры
async function startCamera() {
    try {
        stream = await navigator.mediaDevices.getUserMedia({
            video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: "user" }
        });
        video.srcObject = stream;
        await video.play();
        setStatus('Камера активна. Готов к регистрации или поиску', false);
        registerBtn.disabled = false;
        checkDbBtn.disabled = false;
        overlay.style.opacity = '0';
    } catch (err) {
        console.error("Camera error:", err);
        setStatus('Нет доступа к камере', false);
        showAlert('Не удалось открыть камеру. Проверьте разрешения.', 'danger');
    }
}

// Остановка камеры
function stopCamera() {
    if (stream) {
        stream.getTracks().forEach(track => track.stop());
        stream = null;
    }
}

// Захват кадра → base64
function captureFrame() {
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0);
    return canvas.toDataURL('image/jpeg', 0.85);
}

// ────────────────────────────────────────────────
// РЕГИСТРАЦИЯ
// ────────────────────────────────────────────────
registerBtn.addEventListener('click', () => {
    if (isProcessing) return;
    registerModal.show();
});

document.getElementById('submitRegister').addEventListener('click', async () => {
    if (isProcessing) return;
    isProcessing = true;

    const form = document.getElementById('registerForm');
    if (!form.checkValidity()) {
        form.reportValidity();
        isProcessing = false;
        return;
    }

    try {
        setStatus('Регистрация нового лица...', true);
        registerBtn.disabled = checkDbBtn.disabled = true;

        const fullName = document.getElementById('full_name')?.value.trim();
        const passport = document.getElementById('passport')?.value.trim();
        const genderStr = document.getElementById('gender')?.value;

        if (!fullName) {
            showAlert('Обязательно укажите ФИО', 'danger');
            return;
        }
        if (!passport) {
            showAlert('Обязательно укажите номер паспорта', 'danger');
            return;
        }

        // Преобразуем gender в число сразу на клиенте
        let gender = null;
        if (genderStr && genderStr !== '') {
            gender = parseInt(genderStr, 10);
            if (isNaN(gender) || (gender !== 1 && gender !== 2)) {
                showAlert('Пол должен быть "Мужской" (1) или "Женский" (2)', 'danger');
                return;
            }
        }

        const payload = {
            photos_base64: captureFrame(),
            full_name: fullName,
            passport: passport,
            gender: gender,                     // теперь число или null
            citizenship: document.getElementById('citizenship')?.value?.trim() || null,
            birth_date: document.getElementById('birth_date')?.value || null,
            visa_type: document.getElementById('visa_type')?.value?.trim() || null,
            visa_number: document.getElementById('visa_number')?.value?.trim() || null,
            entry_date: document.getElementById('entry_date')?.value || null,
            exit_date: document.getElementById('exit_date')?.value || null
        };

        console.log('→ Отправка на /register:', payload);

        const response = await fetch('/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        let result;
        try {
            result = await response.json();
        } catch {
            result = { message: 'Сервер вернул некорректный ответ' };
        }

        if (response.ok) {
            const msg = result.message || `Успешно зарегистрирован (ID: ${result.person_id || '—'})`;
            showAlert(msg, 'success');
            registerModal.hide();
            form.reset();
        } else {
            const errMsg = result.detail?.[0]?.msg
                || result.detail
                || result.message
                || 'Ошибка на сервере';
            showAlert(errMsg, 'danger');
            console.error('Ошибка регистрации:', result);
        }
    } catch (err) {
        showAlert('Ошибка соединения или сервера', 'danger');
        console.error(err);
    } finally {
        setStatus('Готов', false);
        registerBtn.disabled = checkDbBtn.disabled = false;
        isProcessing = false;
    }
});

// ────────────────────────────────────────────────
// ПОИСК ПО БАЗЕ
// ────────────────────────────────────────────────
checkDbBtn.addEventListener('click', async () => {
    if (isProcessing) return;
    isProcessing = true;

    try {
        setStatus('Поиск по лицу...', true);
        checkDbBtn.disabled = registerBtn.disabled = true;

        const imageData = captureFrame();

        const response = await fetch('/search', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ photos_base64: imageData })
        });

        if (!response.ok) {
            const err = await response.json().catch(() => ({}));
            throw new Error(err.message || 'Ошибка поиска');
        }

        const data = await response.json();

        searchMatches.innerHTML = '';

        if (data.matches?.length > 0) {
            data.matches.forEach(match => {
                const div = document.createElement('div');
                div.className = 'list-group-item list-group-item-action';
                div.innerHTML = `
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <strong>ФИО:</strong> ${match.full_name || '—'}<br>
                            <strong>Паспорт:</strong> ${match.passport || '—'}<br>
                            <strong>Гражданство:</strong> ${match.citizenship || '—'}<br>
                            <strong>Совпадение:</strong> ${(match.similarity * 100).toFixed(1)}%
                        </div>
                        <span class="badge ${match.similarity > 0.62 ? 'bg-success' : 'bg-warning'} fs-5">
                            ${match.similarity > 0.62 ? 'Найден' : 'Похож'}
                        </span>
                    </div>
                `;
                searchMatches.appendChild(div);
            });
            searchResult.style.display = 'block';
            showAlert(`Найдено ${data.matches.length} совпадений`, 'success');
        } else {
            searchMatches.innerHTML = '<div class="text-center py-5 text-muted">Совпадений не найдено</div>';
            searchResult.style.display = 'block';
            showAlert('Лицо не найдено в базе', 'warning');
        }
    } catch (err) {
        showAlert(err.message || 'Ошибка при поиске', 'danger');
        console.error(err);
    } finally {
        setStatus('Готово', false);
        checkDbBtn.disabled = registerBtn.disabled = false;
        isProcessing = false;
    }
});

// Очистка результатов
clearBtn.addEventListener('click', () => {
    searchResult.style.display = 'none';
    searchMatches.innerHTML = '';
    showAlert('Результаты очищены', 'info');
});

// Инициализация
window.addEventListener('load', startCamera);
window.addEventListener('beforeunload', stopCamera);